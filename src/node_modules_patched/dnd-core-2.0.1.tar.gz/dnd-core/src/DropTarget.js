export default class DropTarget {
  canDrop() {
    return true;
  }

  hover() { }

  drop() { }
}