export default function stateId(state = 0) {
  return state + 1;
}
